document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.getElementById("registerForm");
    const loginForm = document.getElementById("loginForm");

    if (registerForm) {
        registerForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            const response = await fetch("/auth/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password }),
            });

            if (response.ok) {
                alert("Registration successful! Redirecting to login...");
                window.location.href = "login.html";
            } else {
                alert("Registration failed. Try a different username.");
            }
        });
    }

    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const username = document.getElementById("loginUsername").value;
            const password = document.getElementById("loginPassword").value;

            const response = await fetch("/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password }),
            });

            if (response.ok) {
                alert("Login successful! Redirecting to dashboard...");
                window.location.href = `dashboard.html?username=${username}&password=${password}`;
            } else {
                alert("Login failed. Check your credentials.");
            }
        });
    }
});

//booking
document.addEventListener("DOMContentLoaded", () => {
    const bookingForm = document.getElementById("bookingForm");
    const bookingsTableBody = document.getElementById("bookingsTable").querySelector("tbody");
    const backButton = document.getElementById("backButton");
  
    if (bookingForm) {
      bookingForm.addEventListener("submit", async (e) => {
        e.preventDefault();
  
        const formData = new FormData(bookingForm);
        const date = formData.get("date");
        const slot = formData.get("slot");
  
        const response = await fetch("/booking", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ date, slot }),
        });
  
        if (response.ok) {
          const newRow = bookingsTableBody.insertRow();
          const dateCell = newRow.insertCell(0);
          const slotCell = newRow.insertCell(1);
          dateCell.textContent = date;
          slotCell.textContent = slot;
  
          bookingForm.reset(); // Reset form after submission
          alert("Booked successfully!");
        } else {
          alert("Booking failed. Please try again.");
        }
      });
    }
  
    if (backButton) {
      backButton.addEventListener("click", () => {
        bookingForm.reset(); // Clear the form fields
        window.location.href = "dashboard.html";
      });
    }
  });
  //tournament page
  document.addEventListener("DOMContentLoaded", () => {
    const tournamentForm = document.getElementById("tournamentForm");
    const backButton = document.getElementById("backButton");

    if (tournamentForm) {
        tournamentForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const formData = new FormData(tournamentForm);
            const name = formData.get("name");
            const category = formData.get("category");

            const response = await fetch("/tournaments/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, category }),
            });

            if (response.ok) {
                alert("Thank you for registration!");
                tournamentForm.reset(); // Reset form after submission
            } else {
                alert("Registration failed. Please try again.");
            }
        });
    }

    if (backButton) {
        backButton.addEventListener("click", () => {
            window.location.href = "dashboard.html";
        });
    }
});