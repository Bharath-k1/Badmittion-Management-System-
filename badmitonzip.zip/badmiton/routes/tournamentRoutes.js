const express = require('express');
const Tournament = require('../models/Tournament');
const router = express.Router();

router.post('/register', async (req, res) => {
  const { name, category } = req.body;
  try {
    const tournament = new Tournament({ name, category });
    await tournament.save();
    res.status(200).json({ message: 'Registration successful' });
  } catch (err) {
    res.status(500).json({ message: 'Registration failed' });
  }
});

module.exports = router;