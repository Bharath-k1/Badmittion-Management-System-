const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const adminRoutes = require('./routes/adminRoutes');
const tournamentRoutes = require('./routes/tournamentRoutes');

const app = express();

// Connect to MongoDB
connectDB();

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: 'mongodb://127.0.0.1:27017/badminton-court-management' })
  })
);

// Middleware to protect routes
const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    return next();
  } else {
    res.redirect('/login');
  }
};

app.use('/auth', authRoutes);
app.use('/booking', isAuthenticated, bookingRoutes);
app.use('/admin', isAuthenticated, adminRoutes);
app.use('/tournaments', isAuthenticated, tournamentRoutes);

app.get('/', (req, res) => res.sendFile(__dirname + '/views/index.html'));
app.get('/login', (req, res) => res.sendFile(__dirname + '/views/login.html'));
app.get('/booking', isAuthenticated, (req, res) => res.sendFile(__dirname + '/views/booking.html'));
app.get('/dashboard', isAuthenticated, (req, res) => res.sendFile(__dirname + '/views/booking.html')); // Dashboard page
app.get('/admin', isAuthenticated, (req, res) => res.sendFile(__dirname + '/views/admin.html'));
app.get('/tournament', isAuthenticated, (req, res) => res.sendFile(__dirname + '/views/tournament.html'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Server is running on http://localhost:${PORT}`));