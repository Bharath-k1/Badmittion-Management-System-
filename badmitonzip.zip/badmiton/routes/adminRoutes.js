const express = require('express');
const Booking = require('../models/Booking');
const Tournament = require('../models/Tournament');
const router = express.Router();

router.get('/bookings', async (req, res) => {
  try {
    const bookings = await Booking.find().populate('user');
    res.json(bookings);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.get('/tournaments', async (req, res) => {
  try {
    const tournaments = await Tournament.find();
    res.json(tournaments);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

router.post('/tournament', async (req, res) => {
  const { name, date } = req.body;
  try {
    const tournament = new Tournament({ name, date });
    await tournament.save();
    res.redirect('/admin');
  } catch (err) {
    res.redirect('/admin');
  }
});

module.exports = router;