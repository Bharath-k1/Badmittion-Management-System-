const express = require('express');
const Booking = require('../models/Booking');
const router = express.Router();

router.post('/', async (req, res) => {
  const { date, slot } = req.body;
  try {
    const booking = new Booking({
      user: req.session.user._id,
      date,
      slot
    });
    await booking.save();
    res.status(200).json({ message: 'Booking successful' });
  } catch (err) {
    res.status(500).json({ message: 'Booking failed' });
  }
});

router.get('/bookings', async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.session.user._id });
    res.json(bookings);
  } catch (err) {
    res.status(500).send('Server Error');
  }
});

module.exports = router;